package pe.cibertec.retrofitdemo;

/**
 * Created by Android on 20/05/2017.
 */

public final class Constants {

    public static final String BASE_URL = "https://api.backendless.com/9A93628B-54D0-4D9C-FF79-03C4606CCB00/22C006FB-0F32-7A42-FF75-C799CD790300/data/";
}
