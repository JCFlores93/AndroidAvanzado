package pe.cibertec.cleanarchitecture.domain.executor;

import java.util.concurrent.Executor;

/**
 * Created by Android on 27/05/2017.
 */

public interface ThreadExecutor extends Executor {
}
