package pe.cibertec.cleanarchitecture.presentation.view;

import android.content.Context;

/**
 * Created by Android on 27/05/2017.
 */

public interface BaseView {

    Context context();
}
